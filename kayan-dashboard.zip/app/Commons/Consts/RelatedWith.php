<?php

namespace App\Commons\Consts;

class RelatedWith
{
    const PRODUCT = "PRODUCT";
    const CATEGORY = "CATEGORY";
    const CLIENT_GROUP = "CLIENT_GROUP";
}
