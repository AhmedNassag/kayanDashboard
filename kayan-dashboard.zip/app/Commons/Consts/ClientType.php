<?php

namespace App\Commons\Consts;

class ClientType
{
    const DIRECT_SALE = "DIRECT_SALE";
    const MOBILE = "MOBILE";
    const WEB = "WEB";
}
