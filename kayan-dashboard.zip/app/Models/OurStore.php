<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OurStore extends Model
{
    protected $guarded = [];
}
