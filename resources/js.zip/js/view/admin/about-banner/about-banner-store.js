import { reactive } from "vue";
export default reactive({
    onFormShow: false
})
